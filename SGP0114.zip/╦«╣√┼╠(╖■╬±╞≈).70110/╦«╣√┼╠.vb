﻿Imports ToolModule

Public Class Form1

    Private WithEvents ListenServer As ServerSocketClass
    Private WithEvents Client As ClientSocketClass
    Public WithEvents Server As ToListenClientClass
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MainStart()
        Button1.Text = LogicModule.ItemVersion
    End Sub

    Private Sub Form1_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        End
    End Sub


End Class
