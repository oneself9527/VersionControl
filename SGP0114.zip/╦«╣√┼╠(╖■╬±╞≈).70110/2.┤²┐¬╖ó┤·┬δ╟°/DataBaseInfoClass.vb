﻿

Public Class DatabaseInfoClass
    ''' <summary>
    ''' 各分区总赢次数
    ''' </summary>
    ''' <remarks></remarks>
    Public TotalWinNum(GameMachineCount) As Integer
    ''' <summary>
    ''' 查询数据库所有机台参数信息，并给变量赋值
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SelectAspDbThread()
        '返回本游戏所有字段的参数信息表
        Dim _AllInfo As DataTable = ToDataBank.SelectNewDate()
        '如果返回的参数为空就退出方法
        If Not _AllInfo.Rows.Count > 0 Then Exit Sub
        '循环获取每个字段的信息 赋值给变量 来使用
        For i As Integer = 0 To _AllInfo.Rows.Count - 1
            Dim ii As Integer = i + 1
            '获取个分区总押次数
            BetNum(ii) = CDbl(_AllInfo.Rows(i).Item("_iTotalBettingNum"))
            '获取各分区总赢次数
            TotalWinNum(ii) = CDbl(_AllInfo.Rows(i).Item("_iTotalWinNum"))
            '获取當前中全盤積分的記錄
            OverallRecord(ii) = _AllInfo.Rows(i).Item("_nOverallScoreRecord")
            Try
                '如果游戏输赢百分比 不等于数据库中获取的百分比
                If GaPercentage(ii) <> CDbl(_AllInfo.Rows(i).Item("_fLoseWinRatio")) Then
                    '添加或修改 中奖记录 信息
                End If
                '总计赌注
                TotalBet(ii) = CDbl(_AllInfo.Rows(i).Item("_fTotalWinBetting"))
                '各分区总赢积分
                TotalWin(ii) = CDbl(_AllInfo.Rows(i).Item("_fTotalWinIntegral"))
                '对应樱桃连线以上的奖项是否开放 1开放 0不开放
                CherryIfOpen(ii) = CInt(_AllInfo.Rows(i).Item("_tWhetheOpenYT"))
                ' 游戏输赢百分比，用于 总赢积分/总押注积分>百分比 必输...
                GaPercentage(ii) = CDbl(_AllInfo.Rows(i).Item("_fLoseWinRatio"))
                '获取蓝7，红7，天下奖金抽分
                Blue7Bonus(ii) = CDbl(_AllInfo.Rows(i).Item("_iTotalIntegraBlue7"))
                Red7Bonus(ii) = CDbl(_AllInfo.Rows(i).Item("_fTotalIntegraRed7"))
                WorldBonus(ii) = CDbl(_AllInfo.Rows(i).Item("_fTotalIntegraTX"))
                '获取是否开放蓝7，红7，天下、的状态
                IfOpenBlue7All(ii) = CDbl(_AllInfo.Rows(i).Item("_iWhethOpenBlue7"))
                IfOpenRed7All(ii) = CDbl(_AllInfo.Rows(i).Item("_iWhethOpenRed7"))
                IfOpenWorldAll(ii) = CDbl(_AllInfo.Rows(i).Item("_iWhethOpenTX"))
                '获取强制中奖信息
                ForceWin(ii) = _AllInfo.Rows(i).Item("_nCompelWinInfo")
                '获取是否疯狂送樱桃，水果盘，小B
                IfOpenCrazySendCherry(ii) = CDbl(_AllInfo.Rows(i).Item("_iWhethOpenYT"))
                IfOpenCrazySendBar(ii) = CDbl(_AllInfo.Rows(i).Item("_iWhethOpenXb"))
                IfOpenCrazySendFruitDish(ii) = CDbl(_AllInfo.Rows(i).Item("_iWhethOpenSGL"))
                '获取设置会员限制参数信息
                UsersLimit = _AllInfo.Rows(i).Item("_nLimitUsersRecord")
                '获取蓝7，红7，天下的积分起始分数
                Blue7StartIntegral = CDbl(_AllInfo.Rows(i).Item("_fMinNumBlue7"))
                Red7StartIntegral = CDbl(_AllInfo.Rows(i).Item("_fMinNumRed7"))
                WorldStartIntegral = CDbl(_AllInfo.Rows(i).Item("_fMinNumTX"))
                ' '获取蓝7，红7，天下的积分最高分数限制
                Blue7MaxIntegral = CDbl(_AllInfo.Rows(i).Item("_fMaxNumBlue7"))
                Red7MaxIntegral = CDbl(_AllInfo.Rows(i).Item("_fMaxNumRed7"))
                WorldMaxIntegral = CDbl(_AllInfo.Rows(i).Item("_fMaxNumTX"))
                '疯狂送 遊戲輸贏百分比0.6 ，疯狂送中，中奖的比例 该值越大中奖率越大
                CrazySendPercentage(ii) = CDbl(_AllInfo.Rows(i).Item("_fFreeWinChance"))
                Dim cftemp() As String = _AllInfo.Rows(i).Item("_nNumberQP").Split(",")
                '如果获取的参数是 数值，就分别赋值给樱桃连线次数，水果盘连线次数，小B连线次数
                If IsNumeric(cftemp(10)) Then PersonalCherryNum(ii) = cftemp(10)
                If IsNumeric(cftemp(11)) Then PersonalFruitDishNum(ii) = cftemp(11)
                If IsNumeric(cftemp(12)) Then PersonalSmallBarNum(ii) = cftemp(12)
                '获取蓝7，红7，天下彩金
                Blue7Money = _AllInfo.Rows(i).Item("_fWholePrizeBlue7")
                Red7Money = _AllInfo.Rows(i).Item("_fWholePrizeRed7")
                WorldMoney = _AllInfo.Rows(i).Item("_fWholePrizeTX")
            Catch ex As Exception
                GameStatusRecord("GameLogicModule->UpdateBackgroundParameter方法-> 查询数据库所有机台参数信息，并给变量赋值时发生错误", ex)
            End Try
        Next
    End Sub

End Class
