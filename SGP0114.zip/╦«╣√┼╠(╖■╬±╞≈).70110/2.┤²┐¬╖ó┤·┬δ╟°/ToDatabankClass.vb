﻿Imports ToolModule
Imports System.Data.SqlClient
''' <summary>
''' 对数据库进行操作的函数集合类
''' </summary>
Public Class ToDatabankClass
    ''' <summary>
    ''' 配置数据库控制对象
    ''' </summary>
    Private ConfigDB As SQLServerControlClass

    ''' <summary>
    ''' 构造方法
    ''' </summary>
    ''' <param name="_ConfigDatabase"></param>
    Public Sub New(ByVal _ConfigDatabase As String)
        ConfigDB = New SQLServerControlClass(_ConfigDatabase)
    End Sub
#Region "###  根据游戏不同在下方添加数据库操作过程或函数 ###"
    '可以参考  ToConfigDBclass 函数进行开发
    ''' <summary>
    ''' 新NEW一个XML类
    ''' </summary>
    Public XMLInfo As New ToXMLClass
    ''' <summary>
    ''' 获取游戏标记
    ''' </summary>
    Public GameTab As String = XMLInfo.TagName
    ''' <summary>
    ''' 查询 本游戏的所有机台参数 信息
    ''' </summary>
    ''' <returns></returns>
    Public Function SelectNewDate() As DataTable
        Dim sql As String = "select _iNumber,_fLoseWinRatio,_fWholePrizeBlue7,_fWholePrizeRed7,_fWholePrizeTX,_iTotalIntegraBlue7,_fTotalIntegraRed7,_fTotalIntegraTX,_iWhethOpenBlue7,_iWhethOpenRed7,_iWhethOpenTX,_iWhethOpenYT,_iWhethOpenXb,_iWhethOpenSGL,_fMinNumBlue7,_fMinNumRed7,_fMinNumTX,_fMaxNumBlue7,_fMaxNumRed7,_fMaxNumTX,_nNumberQP,_iTotalBettingNum,_iTotalWinNum,_fTotalWinIntegral,_fTotalWinBetting,_nAutoUpdateVIP,_nLimitUsersRecord,_nCompelWinInfo,_fFreeWinChance,_nOverallScoreRecord,_tWhetheOpenYT,_nSeatStatus,_fResidueBetRed7,_fResidueBetBlue7,_fResidueBetTX,_dRecordWinTime,_vRecordUsers from T_EGC__" & GameTab & " with (NOLOCK)"
        Return ConfigDB.ExecParamSQL(1, sql)
    End Function
    ''' <summary>
    '''各分区的所有参数信息
    ''' </summary>
    ''' <returns></returns>
    Public Function SelectParameter() As String
        Dim sql As String = "select  _vParameterInfo  from T_EGC__" & GameTab & " where _iNumber = 1"
        Return ConfigDB.ExecParamSQL(1, sql)
    End Function
    ''' <summary>
    ''' 查询数据库中的
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>(ALL天下,ALL红7,ALL蓝7,ALL大B,ALL中B,ALL杂7,天天天,红777,蓝777,小BAR，樱桃连线，水果盘，小Bar)</remarks>
    Public Function SelectWinningOfSgp(ByVal _fq As Integer) As String
        Dim sql As String = "select _nNumberQP  from  T_EGC__SGP  with (NOLOCK) where _iNumber=@fq"
        Dim sqlparams() As SqlClient.SqlParameter = New SqlParameter() {New SqlParameter("@fq", _fq)}
        Return ConfigDB.ExecParamSQL(2， sql, sqlparams)
    End Function
    ''' <summary>
    ''' 更新数据库中的f_Winning字段
    ''' </summary>
    ''' <param name="_fq">分区</param>
    ''' <param name="_cftemp">数据值</param>
    ''' <remarks></remarks>
    Public Sub UpdateWinningOfSgp(ByVal _cftemp As String, ByVal _fq As Integer)
        Dim sql As String = "update T_EGC__SGP set _nNumberQP=@_nNumberQP where _iNumber=@fq"
        Dim sqlparams() As SqlClient.SqlParameter = New SqlParameter() {New SqlParameter("@_nNumberQP", _cftemp), New SqlParameter("@fq", _fq)}
        ConfigDB.ExecParamSQL(3, sql, sqlparams)
    End Sub
    ''' <summary>
    ''' 修改 游戏状态信息
    ''' </summary>
    ''' <param name="_mess">状态信息</param>
    ''' <param name="_account">帐号</param>
    ''' <param name="_fq">分区</param>
    ''' <remarks></remarks>
    Public Sub UpdateByGameMess(ByVal _mess As String, ByVal _account As String, ByVal _fq As Integer)
        Dim sql As String = "update  T_EGC__SGP set _nSeatStatus=@_nSeatStatus,_vRecordUsers=@_vRecordUsers where _iNumber=@_iNumber"
        Dim sqlparams() As SqlParameter = New SqlParameter() {
                New SqlParameter("@f_gameMess", _mess),
                New SqlParameter("@f_useracc", _account),
                New SqlParameter("@f_number", _fq)
        }
        ConfigDB.ExecParamSQL(3, sql, sqlparams)
    End Sub
    ''' <summary>
    ''' 更新水果盘彩金
    ''' </summary>
    ''' <param name="_Bule">蓝7全盘</param>
    ''' <param name="_Red7">红7全盘</param>
    ''' <param name="_TX">天下全盘</param>
    ''' <remarks></remarks>
    Public Sub UpdateMoneyOfSgp(ByVal _Bule As Double, ByVal _Red7 As Double, ByVal _TX As Double)
        Dim sql As String = "update T_EGC__SGP set _fWholePrizeBlue7=@_fWholePrizeBlue7,_fWholePrizeRed7=@_fWholePrizeRed7 ,_fWholePrizeTX=@_fWholePrizeTX"
        Dim sqlparams() As SqlClient.SqlParameter = New SqlParameter() {
            New SqlParameter("@_fWholePrizeBlue7", _Bule), New SqlParameter("@_fWholePrizeRed7", _Red7), New SqlParameter("@_fWholePrizeTX", _TX)}
        ConfigDB.ExecParamSQL(3, sql, sqlparams)
    End Sub
    ''' <summary>
    ''' 修改 总押和总赢 次数
    ''' </summary>
    ''' <param name="_zy">总押</param>
    ''' <param name="_zying">总赢</param>
    ''' <param name="_fq">分区</param>
    ''' <remarks></remarks>
    Public Sub UpdateZyaAndZyingCount(ByVal _zy As Integer, ByVal _zying As Integer, ByVal _fq As Integer)
        Dim sql As String = "update T_EGC__SGP set _iTotalBettingNum=@_iTotalBettingNum,_iTotalWinNum=@_iTotalWinNum where _iNumber=@_iNumber"
        Dim sqlparams() As SqlParameter = New SqlParameter() {
                New SqlParameter("@_iTotalBettingNum", _zy),
                New SqlParameter("@_iTotalWinNum", _zying),
                New SqlParameter("@_iNumber", _fq)
        }
        ConfigDB.ExecParamSQL(3， sql, sqlparams)
    End Sub

    ''' <summary>
    ''' 清空 強制中獎
    ''' </summary>
    ''' <param name="_fq">分区</param>
    ''' <remarks></remarks>
    Public Sub MandatoryWin(ByVal _fq As Integer)
        Dim sql As String = "update  T_EGC__SGP  set  _nCompelWinInfo='0' where _iNumber=@f_number"
        Dim sqlparams() As SqlParameter = New SqlParameter() {
            New SqlParameter("@f_number", _fq)
        }
        ConfigDB.ExecParamSQL(3， sql, sqlparams)
    End Sub
    ''' <summary>
    ''' 添加跑马灯
    ''' </summary>
    ''' <param name="_vTag">游戏名称</param>
    ''' <param name="_nContent">跑马灯内容</param>
    Public Sub InsertAffiche(ByVal _vTag As String, ByVal _nContent As String)
        ConfigDB.ExecParamSQL(1, "insert into T_EGC_Affiche(_vTag,_nContent,_dEndTime)values('" & _vTag & "','" & _nContent & "','" & DateAdd(DateInterval.Day, 1, Now) & "')")
    End Sub
    ''' <summary>
    ''' 清空 机台小人，机台状态初始化
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteInitWeiZi(ByVal _iNumber As Integer)
        Dim sql As String = "update T_EGC__SGP  set _nSeatStatus='機台無人' where _iNumber=@_iNumber"
        Dim sqlparams() As SqlParameter = New SqlParameter() {
            New SqlParameter("@_iNumber", _iNumber)
        }
        ConfigDB.ExecParamSQL(3, sql, sqlparams)
    End Sub

    ''' <summary>
    ''' 记录调阅演示数据
    ''' </summary>
    ''' <param name="_BillId">演示数据ID</param>
    ''' <param name="_Participants">玩家帐号</param>
    ''' <param name="_Content">演示內容</param>
    Public Sub ToGameNote(ByVal _BillId As String, ByVal _Participants As String, ByVal _Content As String)
        Dim _SQLStr As String = "insert into   此处填写调阅表名 ([f_BillId],[f_Participants],[f_Content],[f_Time]) values(N'" & _BillId & "',N'" & _Participants & "',N'" & _Content & "','" & Now() & "')"
        ' AsynExecParamSQL(_SQLStr, PublicModule.SQLServerConnStr_DY)
    End Sub
#End Region

End Class
