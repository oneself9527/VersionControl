﻿Imports ToolModule
Imports System.Collections.Concurrent
Imports System.Threading
''' <summary>
''' 与客户端交互的模块
''' </summary>
Public Class ToListenClientClass
    ''' <summary>
    ''' 监听APP连入的服务器SOCKET
    ''' </summary>
    Private WithEvents ListenServer As ServerSocketClass
    ''' <summary>
    ''' 用来记录长时间未操作被踢出的用户
    ''' </summary>
    Public ErrorUser As UserClass
    ''' <summary>
    ''' 构造方法
    ''' </summary>
    Public Sub New(ByVal _ListenIP As String, ByVal _ListenPort As Integer, ByVal _ListenCount As Integer)
        ListenServer = New ServerSocketClass(_ListenIP, _ListenPort, _ListenCount)
        ListenServer.StartListen()
        '未操作控制线程
        NoActiveTh.Start()
        '心跳验证线程
        'HeartTh.Start()
    End Sub
    ''' <summary>
    ''' 销毁本类
    ''' </summary>
    Public Sub Dispose()
        ListenServer.Dispose()
        UserList.Clear()
    End Sub


    ''' <summary>
    ''' 当有接收应用层数据自动触发
    ''' </summary>
    ''' <param name="_Msgstr"></param>
    ''' <param name="_SocketUser"></param>
    Private Sub UesrReceiveAppEvent(ByVal _Msgstr As String, ByVal _SocketUser As ServerUserClass) Handles ListenServer.UesrReceiveAppEvent
        '数据格式 (校验码 周+小时+分+秒+毫秒)
        '用途心跳 CH>游戏服务器标记>校验码>信息序号
        '转发数据 ZF>游戏服务器标记>校验码>信息序号>信息标头?内容
        Try
            '拆分接收数据
            Dim Data() As String = _Msgstr.Split(">")
            Dim CheckCode As String = Data(2)
            Dim User As UserClass = New UserClass
            '为了测试方便，直接验证成功
            If UserList.ContainsKey(CheckCode) = True Then
                User = UserList(CheckCode)
                If User.Socket IsNot _SocketUser Then User.Socket = _SocketUser
                '判断用户之前是否掉线 如果是 判断为重连用户 触发重连事件
                If User.OnLine = False Then
                    User.OnLine = True
                    UesReconnEvent(User)
                End If
            End If
            User.HeartTimes = 0
            '根据数据格式，做相应处理
            Select Case Data(0)
                Case "CH" '心跳无需验证
                    _SocketUser.SendAppData(_Msgstr) '返回心跳数据
                Case "ZF"
                    User.ActiveTime = Now '记录活跃时间
                    '接收到TC APP返回大厅 删除用户信息
                    If Data(4) = "TC" Then
                        If UserList.ContainsKey(CheckCode) Then
                            '修改机台为无人状态
                            ManageDB2.DeleteInitWeiZi(User.MachineNumber)
                            GameStatusRecord("ToListenClientClass->UesrReceiveAppEvent方法->玩家退出机台,账号为：" & User.Account & "," & "余额积分为：" & User.Integral)
                            '销毁用户类
                            UserList(CheckCode).Dispose()
                            '将用户从列表中删除
                            UserList.TryRemove(CheckCode, User)
                            Exit Sub
                        End If
                    End If
                    UesrReceiveEvent(Data(4).Split("?")(0), Data(4).Split("?")(1), User)
            End Select
        Catch ex As Exception
            GameStatusRecord("ToListenClientClass->UesrReceiveAppEvent方法->接收应用层数据发生错误", ex)
        End Try
    End Sub
    ''' <summary>
    ''' 心跳验证线程
    ''' </summary>
    Private HeartTh As Thread = New Thread(AddressOf HeartTest)
    ''' <summary>
    ''' 心跳测试掉线
    ''' </summary>
    Private Sub HeartTest()
        While True
            Try
                '遍历用户字典
                For Each user As UserClass In UserList.Values
                    ErrorUser = user
                    '验证次数+1
                    user.HeartTimes += 1
                    '15s没有心跳触发且用户处于连接状态
                    If user.HeartTimes > 20 AndAlso user.OnLine = True Then
                        user.OnLine = False
                        GameStatusRecord("ToListenClientClass->HeartTest方法->玩家心跳掉线,账号为：" & ErrorUser.Account & "," & "余额积分为：" & ErrorUser.Integral)
                    End If
                Next
            Catch ex As Exception
                GameStatusRecord("ToListenClientClass->HeartTest方法->测试玩家心跳掉线发生错误,账号为：" & ErrorUser.Account & "," & "余额积分为：" & ErrorUser.Integral, ex)
            End Try
            '1秒一次
            Threading.Thread.Sleep(1000)
        End While
    End Sub
    ''' <summary>
    ''' 长时间未操作控制线程
    ''' </summary>
    Private NoActiveTh As Thread = New Thread(AddressOf NoActiveTh1)
    ''' <summary>
    ''' 长时间未操作方法 5分钟踢掉
    ''' </summary>
    Private Sub NoActiveTh1()
        '限定时长
        Dim outtime As Integer = 300
        While True
            Try
                '遍历用户字典
                For Each user As UserClass In UserList.Values
                    '用户处于连接状态
                    If user.OnLine = True Then
                        '获取时间差
                        Dim spTime As TimeSpan = Now - user.ActiveTime
                        '时间超时
                        If spTime.TotalSeconds > outtime Then
                            ErrorUser = user
                            '向登陆服务器发送提出请求
                            ManageServer.ClientSocket.SendAppData("TC?" & user.CheckCode)
                            '修改机台为无人状态
                            ManageDB2.DeleteInitWeiZi(user.MachineNumber)
                            '向客户端发送返回大厅指令
                            user.SendData("OUT")
                            GameStatusRecord("ToListenClientClass->NoActiveTh1方法->玩家长时间未操作被强制退出机台,账号为：" & ErrorUser.Account & "," & "余额积分为：" & ErrorUser.Integral)
                            '销毁socket
                            user.Dispose()
                            '将该用户删除
                            UserList.TryRemove(user.CheckCode, user)
                        End If
                    End If
                Next
            Catch ex As Exception
                GameStatusRecord("ToListenClientClass->NoActiveTh1方法->玩家长时间未操作被强制退出机台时发生错误,账号为：" & ErrorUser.Account & "," & "余额积分为：" & ErrorUser.Integral, ex)
            End Try
            '10秒一次
            Threading.Thread.Sleep(10000)
        End While
    End Sub
End Class
